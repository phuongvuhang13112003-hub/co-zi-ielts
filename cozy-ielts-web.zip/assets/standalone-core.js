// ===== Standalone edition: storage + optional GitHub Gist sync, browser voices, speech recognition =====
window.STANDALONE = true;
// ---- per-key timestamps so two devices can merge ----
const META_K = 'cozy__meta', SYNC_K = 'cozy__sync';
const metaGet = () => { try { return JSON.parse(localStorage.getItem(META_K) || '{}'); } catch (e) { return {}; } };
const metaSet = m => { try { localStorage.setItem(META_K, JSON.stringify(m)); } catch (e) {} };
const _local = Store.local.bind(Store);
Store.local = function (k, v) { if (v !== undefined && k !== 'last') { const m = metaGet(); m[k] = Date.now(); metaSet(m); Sync.dirty(); } return _local(k, v); };
Store.del = Store.del || (async k => { try { localStorage.removeItem('cozy_' + k); } catch (e) {} });
const _del = Store.del.bind(Store);
Store.del = async function (k) { const m = metaGet(); m[k] = -Date.now(); metaSet(m); Sync.dirty(); return _del(k); };
Store.init = async function () {
  this.mode = 'local';
  try { if (navigator.storage && navigator.storage.persist) Store.persisted = await navigator.storage.persist(); } catch (e) {}
  try { await withTimeout(Sync.pull(), 8000); } catch (e) {}
};
// ---- GitHub Gist sync (optional, personal token kept only on this device) ----
const Sync = {
  cfg() { try { return JSON.parse(localStorage.getItem(SYNC_K) || 'null'); } catch (e) { return null; } },
  save(c) { localStorage.setItem(SYNC_K, JSON.stringify(c)); },
  on() { const c = this.cfg(); return !!(c && c.token); },
  t: null, busy: false,
  dirty() { if (!this.on()) return; clearTimeout(this.t); this.t = setTimeout(() => this.push().catch(() => {}), 20000); },
  bundle() { const m = metaGet(), keys = {}; for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (!k.startsWith('cozy_') || k === META_K || k === SYNC_K || k === 'cozy_last') continue; const kk = k.slice(5); keys[kk] = { t: m[kk] || 1, v: localStorage.getItem(k) }; } Object.entries(m).forEach(([k, t]) => { if (t < 0 && !keys[k]) keys[k] = { t, v: null }; }); return { app: 'cozy-ielts', v: 2, at: Date.now(), keys }; },
  async api(path, opt = {}) { const c = this.cfg(); const r = await fetch('https://api.github.com' + path, Object.assign({ headers: { Authorization: 'Bearer ' + c.token, Accept: 'application/vnd.github+json', 'Content-Type': 'application/json' } }, opt)); if (!r.ok) throw { code: r.status }; return r.json(); },
  async remote() { const c = this.cfg(); if (!c.gist) return null; const g = await this.api('/gists/' + c.gist); const f = g.files && g.files['cozy-ielts-sync.json']; if (!f) return null; const txt = f.truncated ? await (await fetch(f.raw_url)).text() : f.content; return JSON.parse(txt); },
  merge(rb) { if (!rb || !rb.keys) return 0; const m = metaGet(); let n = 0; Object.entries(rb.keys).forEach(([k, e]) => { const lt = m[k] || 0; if (Math.abs(e.t) > Math.abs(lt)) { if (e.v == null) localStorage.removeItem('cozy_' + k); else localStorage.setItem('cozy_' + k, e.v); m[k] = e.t; n++; } }); metaSet(m); return n; },
  async pull() { if (!this.on()) return 0; const rb = await this.remote(); const n = this.merge(rb); const c = this.cfg(); c.last = Date.now(); this.save(c); return n; },
  async push() { if (!this.on() || this.busy) return; this.busy = true;
    try { const c = this.cfg(); try { this.merge(await this.remote()); } catch (e) {}
      const body = JSON.stringify({ description: 'Cozy IELTS sync (private)', files: { 'cozy-ielts-sync.json': { content: JSON.stringify(this.bundle()) } } });
      if (c.gist) await this.api('/gists/' + c.gist, { method: 'PATCH', body }); else { const g = await this.api('/gists', { method: 'POST', body: JSON.stringify(Object.assign(JSON.parse(body), { public: false })) }); c.gist = g.id; }
      c.last = Date.now(); this.save(c); const el = document.getElementById('syncst'); if (el) el.textContent = new Date(c.last).toLocaleString();
    } finally { this.busy = false; } }
};
window.Sync = Sync;
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden' && Sync.on()) { clearTimeout(Sync.t); Sync.push().catch(() => {}); } });
// ---- voices: pick the most natural English voice, user can choose ----
const VPREF = 'cozy__voice';
Voice.voices = () => (window.speechSynthesis ? speechSynthesis.getVoices() : []).filter(v => /^en[-_]/i.test(v.lang) || /^en$/i.test(v.lang));
Voice.rank = v => (/natural|neural|online/i.test(v.name) ? 40 : 0) + (/google/i.test(v.name) ? 25 : 0) + (/en[-_]GB/i.test(v.lang) ? 6 : /en[-_]US/i.test(v.lang) ? 5 : 0) + (v.localService ? 0 : 3);
Voice.best = function (alt) { const vs = this.voices(); if (!vs.length) return null; const pref = localStorage.getItem(VPREF); const sorted = vs.slice().sort((a, b) => this.rank(b) - this.rank(a)); const main = vs.find(v => v.name === pref) || sorted[0]; if (!alt) return main; return sorted.find(v => v !== main && v.lang.slice(0, 5) !== main.lang.slice(0, 5)) || sorted.find(v => v !== main) || main; };
Voice.lines = function (lines) {
  const rate = this.rate; if (!window.speechSynthesis) return Promise.resolve();
  speechSynthesis.cancel();
  return new Promise((res, rej) => { let i = 0;
    const next = () => { if (i >= lines.length) return res(); const [sp, text] = lines[i++]; const u = new SpeechSynthesisUtterance(text); const v = this.best(sp === 'W' || sp === 'X'); if (v) { u.voice = v; u.lang = v.lang; } else u.lang = 'en-GB'; u.rate = rate * 0.95; u.pitch = sp === 'W' ? 1.12 : 1;
      u.onend = next; u.onerror = e => (e.error === 'interrupted' || e.error === 'canceled') ? rej({ code: 'viewer_stopped' }) : next(); speechSynthesis.speak(u); };
    next(); });
};
if (window.speechSynthesis) speechSynthesis.onvoiceschanged = () => {};
// ---- speech recognition (Chrome / Edge / Android; needs internet) ----
function makeRecognizer() {
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition; if (!SR) return null;
  const cb = { f: () => {}, p: () => {}, s: () => {} }; let rec = null, on = false;
  return {
    onFinal(f) { cb.f = f; }, onPartial(f) { cb.p = f; }, onState(f) { cb.s = f; },
    start() { return new Promise((res, rej) => { try { rec = new SR(); rec.lang = 'en-US'; rec.continuous = true; rec.interimResults = true;
      rec.onresult = e => { let interim = ''; for (let i = e.resultIndex; i < e.results.length; i++) { const r = e.results[i]; if (r.isFinal) cb.f({ text: r[0].transcript.trim() }); else interim += r[0].transcript; } cb.p({ text: interim }); };
      rec.onerror = e => { if (e.error === 'not-allowed' || e.error === 'service-not-allowed') rej({ code: 'not_granted' }); };
      rec.onend = () => { on = false; cb.s({ state: 'idle' }); Voice.recEnd && Voice.recEnd(); };
      rec.onstart = () => { on = true; cb.s({ state: 'listening' }); res(); };
      rec.start(); } catch (e) { rej(e); } }); },
    stop() { try { rec && rec.stop(); } catch (e) {} return Promise.resolve(); }
  };
}
Voice.init = async function () {
  this.t = null; this.d = makeRecognizer();
  if (this.d) {
    this.d.onFinal(({ text }) => { const el = this.target; if (el) { el.value = (el.value ? el.value.replace(/\s*$/, ' ') : '') + text; el.dispatchEvent(new Event('input')); } const p = $('#dictPartial'); if (p) p.textContent = ''; });
    this.d.onPartial(({ text }) => { const p = $('#dictPartial'); if (p) p.textContent = text; });
    this.d.onState(({ state }) => { $$('.mic').forEach(b => b.classList.toggle('on', state === 'listening')); });
  }
};
