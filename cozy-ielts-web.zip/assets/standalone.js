// ===== Standalone edition: offline replacements for every AI feature =====
AI_TOPIC.t = ['Bài học của tôi', 'My lessons'];
LGROUPS[2][3] = LGROUPS[2][3].filter(t => t[0] !== 'ai');
// ---------- 1. Offline dictionary: WordNet definitions + your own Vietnamese meanings ----------
(function prefillDict() {
  const WNd = window.WN || {};
  LV.forEach(l => { DICT[l] = DICT[l] || {}; const m = WNd[l] || {}; levelList(l).forEach(x => { const e = m[x.w + '|' + x.p]; if (e && !DICT[l][x.w]) DICT[l][x.w] = [e[0].split(' | ')[0].slice(0, 90), e[1] || '']; }); });
})();
const wnEntry = (l, w) => { const L = levelList(l).find(x => x.w === w); return L && (window.WN || {})[l] && WN[l][w + '|' + L.p]; };
const _dictView = VIEWS.dict;
VIEWS.dict = (l = 'B1', pg = '0', q = '') => {
  _dictView(l, pg, q);
  const note = $$('#main > p.small.muted').pop(); if (note) note.innerHTML = tx('Danh sách từ: CEFR-J Wordlist v1.5 (Tono Laboratory, TUFS) · Octanove Vocabulary Profile C1/C2 (CC BY-SA 4.0). Định nghĩa tiếng Anh, ví dụ và từ đồng nghĩa: Princeton WordNet 3.0 (WordNet License). Bấm "VI" để tra nghĩa tiếng Việt, bấm ✎ để ghi nghĩa của riêng bạn – nghĩa bạn ghi sẽ thay định nghĩa tiếng Anh trong bài luyện.', 'Lists: CEFR-J v1.5 · Octanove C1/C2 (CC BY-SA 4.0). Definitions: Princeton WordNet 3.0. Tap VI to look up Vietnamese, ✎ to save your own meaning.');
  $$('#dlist .drow').forEach(r => { const w = r.dataset.w; const e = wnEntry(l, w);
    r.insertAdjacentHTML('beforeend', '<span class="dtools"><a class="chipb sm" target="_blank" rel="noopener" href="https://translate.google.com/?sl=en&tl=vi&op=translate&text=' + encodeURIComponent(w) + '">VI</a><a class="chipb sm" target="_blank" rel="noopener" href="https://dictionary.cambridge.org/dictionary/english-vietnamese/' + encodeURIComponent(w.replace(/ /g, '-')) + '">Cambridge</a><button class="chipb sm" data-act="dictEdit" data-arg="' + esc(l + '|' + w) + '">✎</button></span>' + (e && e[2] ? '<span class="small dsyn">≈ ' + esc(e[2]) + '</span>' : '')); });
};
ACT.dictEdit = a => { const [l, w] = a.split('|'); const cur = (DICT[l] || {})[w] || ['', ''];
  modal('<form id="dedf" class="stackf"><h2>' + esc(w) + '</h2><label>' + tx('Nghĩa tiếng Việt của bạn', 'Your Vietnamese meaning') + '<input name="vi" value="' + esc(/[à-ỹđ]/i.test(cur[0]) ? cur[0] : '') + '" maxlength="60" required></label><label>' + tx('Câu ví dụ', 'Example') + '<input name="ex" value="' + esc(cur[1]) + '" maxlength="140"></label><button class="btn">' + tx('Lưu', 'Save') + '</button></form>');
  $('#dedf').addEventListener('submit', e => { e.preventDefault(); const d = new FormData(e.target); DICT[l][w] = [String(d.get('vi')).trim(), String(d.get('ex')).trim()]; const it = levelList(l).find(x => x.w === w); saveDictChunk(l, chunkOf(it.i)); closeModal(); toast(tx('Đã lưu nghĩa.', 'Saved.')); rerender(); }); };
// keep user meanings when chunks are saved: only store Vietnamese meanings
saveDictChunk = function (l, ch) { const m = {}; levelList(l).forEach(x => { const v = DICT[l][x.w]; if (chunkOf(x.i) === ch && v && /[à-ỹđ]/i.test(v[0])) m[x.w] = v; }); Store.set('dict_' + l + '_' + ch, { m }); };

// ---------- 2. Offline writing analyser ----------
let SPELL = null;
const loadScript = src => new Promise((res, rej) => { if (document.querySelector('script[src="' + src + '"]')) return res(); const s = document.createElement('script'); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
async function spellSet() { if (SPELL) return SPELL; try { await loadScript('assets/spell.js'); } catch (e) {} SPELL = new Set(String(window.SPELLWORDS || '').split(' '));
  LV.forEach(l => levelList(l).forEach(x => x.w.toLowerCase().split(/[ -]/).forEach(p => SPELL.add(p))));
  allSubs().forEach(s => s.s.w.forEach(w => w[0].toLowerCase().split(/[ -]/).forEach(p => SPELL.add(p))));
  ('i me my mine you your yours he him his she her hers it its we us our ours they them their theirs this that these those a an the and or but nor so yet for of to in on at by with from into onto upon about above below over under between among through during before after since until while although though because unless whereas whether if than as like which who whom whose what when where why how not no yes very also too only just even still already ever never always often sometimes usually rarely is am are was were be been being do does did done doing have has had having can could may might must shall should will would ought there here then thus hence however therefore moreover furthermore nevertheless nonetheless meanwhile otherwise instead besides further firstly secondly thirdly lastly finally overall whilst amongst towards upon within without across along around behind beside beyond despite except inside near off onto outside per regarding toward via versus etc e.g i.e ' +
   'went gone came saw seen took taken gave given made said told thought brought bought caught taught fought sought felt left kept slept met paid sent spent built lent meant found held stood understood lost won sold rose risen fell fallen grew grown drew drawn flew flown knew known threw thrown wrote written spoke spoken broke broken chose chosen froze frozen drove driven rode ridden ate eaten began begun drank drunk sang sung swam swum ran wore worn tore torn hid hidden bit bitten forgot forgotten got gotten shook shaken stole stolen woke woken children men women people feet teeth mice geese lives wives knives leaves analyses crises criteria phenomena data media better best worse worst more most less least further furthest').split(' ').forEach(x => SPELL.add(x));
  return SPELL; }
function known(w, S1) { if (S1.has(w)) return true; const tries = [w.replace(/'s$/, ''), w.replace(/s$/, ''), w.replace(/es$/, ''), w.replace(/ies$/, 'y'), w.replace(/ed$/, ''), w.replace(/ed$/, 'e'), w.replace(/d$/, ''), w.replace(/ied$/, 'y'), w.replace(/ing$/, ''), w.replace(/ing$/, 'e'), w.replace(/([a-z])\1ing$/, '$1'), w.replace(/([a-z])\1ed$/, '$1'), w.replace(/ly$/, ''), w.replace(/ily$/, 'y'), w.replace(/er$/, ''), w.replace(/est$/, ''), w.replace(/ier$/, 'y'), w.replace(/iest$/, 'y'), w.replace(/ness$/, ''), w.replace(/ment$/, ''), w.replace(/ation$/, 'e'), w.replace(/ically$/, 'ic'), w.replace(/ability$/, 'able'), w.replace(/^(un|re|dis|non|over|under|pre|mis|co|inter|multi|self)-?/, '')]; return tries.some(t => t.length > 1 && S1.has(t)); }
const LINKERS = ['however', 'moreover', 'furthermore', 'in addition', 'additionally', 'therefore', 'consequently', 'as a result', 'thus', 'hence', 'nevertheless', 'nonetheless', 'on the other hand', 'in contrast', 'by contrast', 'whereas', 'while', 'although', 'even though', 'despite', 'in spite of', 'for example', 'for instance', 'such as', 'in particular', 'firstly', 'secondly', 'finally', 'in conclusion', 'to conclude', 'overall', 'to sum up', 'similarly', 'likewise', 'because', 'since', 'due to', 'owing to', 'this means', 'in other words', 'not only', 'meanwhile', 'subsequently'];
const INFORMAL = [["don't|doesn't|can't|won't|isn't|aren't|didn't|it's|i'm|they're|we're|wasn't|shouldn't|couldn't", 'Viết đầy đủ (do not, cannot…) – văn học thuật tránh dạng rút gọn'], ['\\ba lot of\\b|\\blots of\\b', 'Thay bằng a great deal of / a large number of / considerable'], ['\\bkids?\\b', 'Dùng children'], ['\\bstuff\\b|\\bthings?\\b', 'Dùng danh từ cụ thể hơn (items, aspects, factors…)'], ['\\bgonna\\b|\\bwanna\\b|\\bgotta\\b', 'Quá thân mật'], ['\\bget\\b|\\bgot\\b', 'Cân nhắc obtain / receive / become'], ['\\bbig\\b', 'significant / substantial / considerable'], ['\\bgood\\b|\\bbad\\b', 'Cụ thể hơn: beneficial, harmful, detrimental…'], ['!', 'Tránh dấu chấm than trong bài học thuật'], ['\\bso\\b,', 'Đầu câu nên dùng Therefore / As a result']];
const STOP = new Set('the a an and or but of to in on at by for with from is are was were be been being this that these those it its they them their there which who what as can could would should will may might more most also not no do does did have has had than such very many much some any all each other into about over between because so if when while one two people'.split(' '));
let LOWW = null;
function advWords(types) { if (!LOWW) { LOWW = new Set(); ['A1', 'A2', 'B1'].forEach(l => levelList(l).forEach(x => LOWW.add(x.w.toLowerCase()))); } const out = new Set(); ['B2', 'C1', 'C2'].forEach(l => levelList(l).forEach(x => { const w = x.w.toLowerCase(); if (!w.includes(' ') && !LOWW.has(w) && types.has(w)) out.add(w); })); return out; }
// ---------- 2. Writing: 6C strengths & weaknesses (no band score) ----------
const REDUNDANT = [['in my personal opinion', 'in my opinion'], ['in my opinion, i think', 'chỉ cần một trong hai'], ['each and every', 'every'], ['due to the fact that', 'because'], ['because of the fact that', 'because'], ['at this point in time', 'now / currently'], ['in today\'s modern world', 'today'], ['it is important to note that', 'bỏ được'], ['there are many people who', 'many people'], ['the reason why is because', 'the reason is that'], ['completely destroy', 'destroy'], ['future plans', 'plans'], ['past history', 'history'], ['return back', 'return'], ['repeat again', 'repeat'], ['very very', 'một từ mạnh hơn (extremely…)']];
const VAGUE = ['things', 'thing', 'stuff', 'something', 'many aspects', 'some problems', 'a lot of', 'lots of', 'nowadays', 'some people', 'many people', 'good', 'bad', 'big', 'nice', 'etc'];
const VNERR = [[/\bdiscuss about\b/i, '"discuss about" → discuss (không có about)'], [/\bmake (\w+) to (\w+)/i, '"make sb to do" → make sb do'], [/\balthough\b[^.]*\bbut\b/i, '"although … but" → bỏ but'], [/\bbecause\b[^.]*,\s*so\b/i, '"because … so" → bỏ so'], [/\baccording to me\b/i, '"according to me" → in my view'], [/\bin my opinion,? i think\b/i, '"In my opinion, I think" → lặp ý'], [/\bpeople is\b/i, '"people is" → people are'], [/\bthere is (many|a lot of|several|some) \w+s\b/i, '"there is + danh từ số nhiều" → there are'], [/\b(he|she) (have|do|go|make|want|need)\b/i, 'Ngôi thứ 3 số ít: động từ thêm -s'], [/\bmore (better|worse|easier|bigger|cheaper|higher|lower)\b/i, '"more better" → better'], [/\ba (a|e|i|o|u)\w+/i, '"a" trước nguyên âm → an (kiểm tra lại)'], [/\bthe most (best|worst)\b/i, '"the most best" → the best'], [/\bcan (to|\w+ed)\b/i, 'Sau can là động từ nguyên mẫu'], [/\bit have\b/i, '"it have" → it has'], [/\b(enjoy|avoid|suggest|consider|finish) to \w+/i, 'enjoy/avoid/suggest/consider + V-ing'], [/\bspend (\w+ )?(time|money|hours?) to \w+/i, 'spend time + V-ing'], [/\b\w*[^aeiou\s]ys\b/i, 'Danh từ tận cùng phụ âm + y → -ies (city → cities)'], [/\bthere (is|was) (many|a lot of|several|some|few|two|three) \w+/i, '"there is + nhiều" → there are'], [/\bresearches\b|\binformations\b|\badvices\b|\bequipments\b|\bknowledges\b/i, 'Danh từ không đếm được không thêm -s']];
const quote = (s, n = 18) => { const w = s.trim().split(/\s+/); return '“' + esc(w.slice(0, n).join(' ')) + (w.length > n ? '…' : '') + '”'; };
async function sixC(text, task, prompt) {
  const S1 = await spellSet(); const n = wc(text); const min = task === 1 ? 150 : 250; const low = text.toLowerCase(); prompt = String(prompt || '').toLowerCase();
  const paras = text.split(/\n\s*\n|\n/).map(p => p.trim()).filter(p => wc(p) >= 8);
  const sents = text.replace(/\n/g, ' ').split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(s => wc(s) >= 3); const lens = sents.map(wc); const avg = lens.reduce((a, b) => a + b, 0) / (lens.length || 1);
  const words = low.match(/[a-z][a-z'-]*/g) || []; const content = words.filter(w => !STOP.has(w) && w.length > 2); const types = new Set(content);
  const C6 = { clear: [[], []], concise: [[], []], concrete: [[], []], correct: [[], []], complete: [[], []], coherent: [[], []] }; const good = (k, t) => C6[k][0].push(t), bad = (k, t) => C6[k][1].push(t);
  // CLEAR
  const longS = sents.filter(s => wc(s) > 35), shortS = sents.filter(s => wc(s) < 6);
  if (avg >= 12 && avg <= 25) good('clear', tx('Độ dài câu vừa phải (trung bình ' + avg.toFixed(0) + ' từ/câu) – dễ theo dõi.', 'Sentence length is easy to follow.')); else if (avg > 25) bad('clear', tx('Câu trung bình ' + avg.toFixed(0) + ' từ – hơi dài, người đọc dễ lạc ý.', 'Sentences are long on average.'));
  longS.slice(0, 2).forEach(s => bad('clear', tx('Câu quá dài (' + wc(s) + ' từ), nên tách đôi: ', 'Split this long sentence: ') + quote(s)));
  const bodies = task === 2 ? paras.slice(1, -1) : paras.slice(1); const weakTopic = bodies.filter(p => /^(for example|for instance|also|and|but|so)\b/i.test(p));
  if (bodies.length && !weakTopic.length) good('clear', tx('Mỗi đoạn thân bài mở bằng một câu nêu ý chính.', 'Body paragraphs open with a topic sentence.'));
  weakTopic.forEach(p => bad('clear', tx('Đoạn này mở đầu bằng ví dụ/từ nối thay vì câu chủ đề: ', 'This paragraph lacks a topic sentence: ') + quote(p, 10)));
  const itStart = sents.filter(s => /^(it|this|that|they)\b/i.test(s)).length; if (itStart >= 4) bad('clear', tx(itStart + ' câu mở đầu bằng It/This/They – kiểm tra xem người đọc có biết chúng thay cho cái gì không.', itStart + ' sentences start with It/This/They – make the reference clear.'));
  // CONCISE
  const red = REDUNDANT.filter(r => low.includes(r[0])); red.forEach(r => bad('concise', tx('Thừa chữ: "' + r[0] + '" → ' + r[1], 'Redundant: "' + r[0] + '" → ' + r[1])));
  const intens = (low.match(/\b(very|really|so|quite|extremely|totally)\b/g) || []).length; if (intens >= 5) bad('concise', tx('Dùng ' + intens + ' từ nhấn (very, really, so…) – thay bằng một tính từ mạnh hơn (very big → enormous).', 'Too many intensifiers.'));
  const rep = Object.entries(content.reduce((m, w) => (m[w] = (m[w] || 0) + 1, m), {})).filter(([w, c]) => c >= 4 && w.length > 3).sort((a, b) => b[1] - a[1]).slice(0, 5);
  rep.forEach(([w, c]) => bad('concise', tx('"' + w + '" lặp ' + c + ' lần – dùng từ đồng nghĩa hoặc đại từ.', '"' + w + '" repeated ' + c + ' times.')));
  if (!red.length && intens < 5 && !rep.length) good('concise', tx('Không thấy cụm thừa chữ hay lặp từ nhiều.', 'No obvious redundancy or heavy repetition.'));
  if (n > min * 1.6) bad('concise', tx(n + ' từ – dài hơn nhiều so với yêu cầu; trong phòng thi viết dài dễ mất thời gian và nhiều lỗi hơn.', 'Much longer than required.'));
  // CONCRETE
  const ex = (low.match(/\b(for example|for instance|such as|a case in point|to illustrate)\b/g) || []).length; const nums = (text.match(/\d[\d.,%]*/g) || []).length;
  const proper = (text.match(/(?<=[a-z,;]\s)[A-Z][a-z]{2,}/g) || []).length;
  if (task === 2) { if (ex) good('concrete', tx('Có ' + ex + ' ví dụ minh hoạ (for example, such as…).', ex + ' examples.')); else bad('concrete', tx('Chưa có ví dụ cụ thể – mỗi đoạn thân bài nên có 1 ví dụ (một quốc gia, một nghiên cứu, một tình huống thật).', 'Add a concrete example to each body paragraph.')); if (proper) good('concrete', tx('Nhắc tới tên riêng/địa danh cụ thể – làm luận điểm thuyết phục hơn.', 'Specific names or places make points convincing.')); }
  else { if (nums >= 6) good('concrete', tx('Dẫn ' + nums + ' số liệu cụ thể từ biểu đồ.', nums + ' figures quoted.')); else bad('concrete', tx('Mới có ' + nums + ' số liệu – Task 1 cần dẫn số cụ thể cho các điểm chính.', 'Quote more figures.')); }
  const vg = VAGUE.filter(v => new RegExp('\\b' + v + '\\b').test(low)); if (vg.length >= 3) bad('concrete', tx('Từ chung chung: ' + vg.join(', ') + ' – thay bằng danh từ/tính từ cụ thể.', 'Vague words: ' + vg.join(', '))); else if (!vg.length) good('concrete', tx('Ít dùng từ chung chung (things, stuff, good, bad…).', 'Few vague words.'));
  // CORRECT
  const errs = VNERR.filter(([re]) => re.test(text)); errs.forEach(([re, m]) => { const mm = text.match(re); bad('correct', esc(m) + (mm ? ' – ' + quote(mm[0], 8) : '')); });
  const unknown = [...new Set(words.filter(w => w.length > 2 && !/'/.test(w) && !known(w, S1)))].slice(0, 12); if (unknown.length) bad('correct', tx('Kiểm tra chính tả: ', 'Check spelling: ') + unknown.map(esc).join(', '));
  const contr = text.match(/\b\w+n't\b|\b(it's|i'm|they're|we're|you're)\b/gi); if (contr) bad('correct', tx('Văn học thuật nên viết đầy đủ: ', 'Avoid contractions: ') + [...new Set(contr)].slice(0, 5).join(', '));
  const capErr = sents.filter(s => /^[a-z]/.test(s)).length + (text.match(/(^|\s)i(\s|')/g) || []).length; if (capErr) bad('correct', tx('Lỗi viết hoa (đầu câu hoặc chữ "I"): ' + capErr + ' chỗ.', capErr + ' capitalisation errors.'));
  if (/ [,.;:]/.test(text) || /[,.;:][A-Za-z]/.test(text)) bad('correct', tx('Dấu câu: không cách trước dấu phẩy/chấm và luôn cách sau dấu.', 'Punctuation spacing.'));
  if (!errs.length && !unknown.length && !contr && !capErr) good('correct', tx('Không phát hiện lỗi thường gặp nào trong danh sách máy kiểm tra (máy không bắt được mọi lỗi ngữ pháp).', 'No common errors detected (the checker cannot catch every error).'));
  // COMPLETE
  if (n >= min) good('complete', tx('Đủ số từ (' + n + '/' + min + ').', 'Word count met.')); else bad('complete', tx('Thiếu số từ: ' + n + '/' + min + ' – trong thi thật bài thiếu từ bị trừ điểm Task Response.', 'Under length: ' + n + '/' + min));
  if (task === 2) {
    const pos = /\b(i (strongly |firmly )?(believe|agree|disagree|argue|feel)|in my (view|opinion)|from my perspective|this essay (will )?(argue|argues))\b/.test(low);
    pos ? good('complete', tx('Nêu rõ quan điểm của mình.', 'Clear position.')) : bad('complete', tx('Chưa thấy câu nêu quan điểm rõ ràng (I believe… / In my view…).', 'No clear position.'));
    if (/both views|discuss both/.test(prompt)) (/\b(on the other hand|others|however|in contrast|whereas|while some|opponents|critics)\b/.test(low) ? good('complete', tx('Có bàn cả hai quan điểm như đề yêu cầu.', 'Both views discussed.')) : bad('complete', tx('Đề yêu cầu bàn CẢ HAI quan điểm – bài mới nghiêng một phía.', 'Discuss both views.')));
    if (/advantages|disadvantages|outweigh/.test(prompt)) (/advantage|benefit|drawback|disadvantage/.test(low) ? good('complete', tx('Có nhắc đến lợi ích và bất lợi.', 'Advantages and disadvantages covered.')) : bad('complete', tx('Đề hỏi lợi/hại – hãy nói rõ cả hai và kết luận bên nào lớn hơn.', 'Cover both sides and weigh them.')));
    if (/causes?|why/.test(prompt) && /solutions?|measures|what can be done|how/.test(prompt)) (/\b(cause|because|due to|result)\b/.test(low) && /\b(solution|should|could|measure|tackle|address)\b/.test(low) ? good('complete', tx('Trả lời cả nguyên nhân và giải pháp.', 'Causes and solutions both covered.')) : bad('complete', tx('Đề có 2 câu hỏi (nguyên nhân/vấn đề và giải pháp) – kiểm tra đã trả lời đủ cả hai.', 'Answer both questions.')));
    /\b(in conclusion|to conclude|to sum up|in summary|overall)\b/.test(low) ? good('complete', tx('Có đoạn kết luận.', 'Has a conclusion.')) : bad('complete', tx('Thiếu đoạn kết luận (In conclusion…).', 'No conclusion.'));
  } else {
    /\b(overall|in general|it is clear|it is evident|generally)\b/.test(low) ? good('complete', tx('Có câu overview tóm tắt xu hướng chính.', 'Overview present.')) : bad('complete', tx('Thiếu overview (Overall, …) – đây là phần quan trọng nhất của Task 1.', 'Missing overview.'));
    /\b(i think|i believe|in my opinion)\b/.test(low) ? bad('complete', tx('Task 1 không nêu ý kiến cá nhân.', 'No opinions in Task 1.')) : good('complete', tx('Không chen ý kiến cá nhân.', 'No personal opinion.'));
  }
  // COHERENT
  const need = task === 1 ? 3 : 4; paras.length >= need ? good('coherent', tx(paras.length + ' đoạn văn rõ ràng.', paras.length + ' clear paragraphs.')) : bad('coherent', tx('Chỉ có ' + paras.length + ' đoạn – nên chia ' + (task === 1 ? '3–4' : '4–5') + ' đoạn (xuống dòng giữa các đoạn).', 'Use ' + need + '+ paragraphs.'));
  const link = LINKERS.filter(l => new RegExp('\\b' + l + '\\b').test(low)); link.length >= 4 ? good('coherent', tx('Từ nối đa dạng: ', 'Varied linkers: ') + link.slice(0, 8).join(', ')) : bad('coherent', tx('Ít từ nối (' + link.length + ') – thêm however, as a result, in addition… để nối ý.', 'Few linking words.'));
  const over = LINKERS.map(l => [l, (low.match(new RegExp('\\b' + l + '\\b', 'g')) || []).length]).filter(x => x[1] >= 3); over.forEach(([l, c]) => bad('coherent', tx('"' + l + '" dùng ' + c + ' lần – thay đổi cách nối.', '"' + l + '" used ' + c + ' times.')));
  const starts = sents.map(s => s.split(/\s+/)[0].toLowerCase()); const same = Object.entries(starts.reduce((m, w) => (m[w] = (m[w] || 0) + 1, m), {})).filter(([w, c]) => c >= 3 && !['the'].includes(w)); same.forEach(([w, c]) => bad('coherent', tx(c + ' câu cùng bắt đầu bằng "' + w + '" – đổi cách mở câu.', c + ' sentences start with "' + w + '".')));
  const refs = (low.match(/\b(this|these|such|which|the former|the latter)\b/g) || []).length; if (refs >= 3) good('coherent', tx('Dùng từ quy chiếu (this, these, which…) để nối câu.', 'Uses referencing.'));
  return C6;
}
const C6N = { clear: ['Clear – Rõ ràng', 'Clear'], concise: ['Concise – Ngắn gọn', 'Concise'], concrete: ['Concrete – Cụ thể', 'Concrete'], correct: ['Correct – Chính xác', 'Correct'], complete: ['Complete – Đầy đủ', 'Complete'], coherent: ['Coherent – Mạch lạc', 'Coherent'] };
selfCheck = function (task, text, ctx, w) {
  const id = 'wa' + uid(); setTimeout(async () => { const box = document.getElementById(id); if (!box) return; const C6 = await sixC(text || ($('#essay') || {}).value || '', task, w && w.prompt); ctx = ctx || {};
    const strong = Object.entries(C6).filter(([, v]) => v[0].length && !v[1].length).map(([k]) => pick(C6N[k])), weak = Object.entries(C6).sort((a, b) => b[1][1].length - a[1][1].length).filter(([, v]) => v[1].length).slice(0, 3).map(([k]) => pick(C6N[k]));
    box.innerHTML = '<h2>' + tx('Nhận xét theo 6C', '6C feedback') + '</h2><p class="small muted">' + tx('Máy phân tích ngay trên thiết bị, không dùng AI và không chấm band – vì máy không đánh giá được chất lượng ý tưởng như giám khảo. Thay vào đó là điểm mạnh và điểm yếu cụ thể theo 6 tiêu chí, kèm trích dẫn từ bài của bạn để sửa.', 'On-device analysis, no AI and no band score. Concrete strengths and weaknesses with quotes from your essay.') + '</p>' +
      '<div class="c6sum">' + (strong.length ? '<p><b class="ok">' + tx('Làm tốt: ', 'Strong: ') + '</b>' + strong.join(' · ') + '</p>' : '') + (weak.length ? '<p><b class="bad">' + tx('Ưu tiên sửa: ', 'Fix first: ') + '</b>' + weak.join(' · ') + '</p>' : '') + '</div>' +
      Object.entries(C6).map(([k, [g, b]]) => '<details class="c6"' + (b.length ? ' open' : '') + '><summary><b>' + pick(C6N[k]) + '</b><span class="small ' + (b.length ? 'bad' : 'ok') + '">' + (b.length ? b.length + tx(' điểm cần sửa', ' to fix') : tx('ổn', 'good')) + '</span></summary>' + (g.length ? '<ul class="chklist">' + g.map(x => '<li class="ok">✓ ' + x + '</li>').join('') + '</ul>' : '') + (b.length ? '<ul class="chklist">' + b.map(x => '<li class="bad">✗ ' + x + '</li>').join('') + '</ul>' : '') + '</details>').join('') +
      '<p class="small muted">' + tx('Gợi ý: sửa các điểm ✗ rồi bấm Nộp bài lần nữa để so sánh. Muốn có điểm band thật, nhờ giáo viên chấm hoặc mở bản Cozy IELTS trên Claude.', 'Fix the ✗ points and resubmit. For a real band, ask a teacher or use the Claude version.') + '</p>' +
      '<div class="row"><button class="btn alt" id="' + id + 'r">' + tx('Sửa và nộp lại', 'Revise & resubmit') + '</button>' + (ctx.place ? '<button class="btn ghost" data-act="nav" data-arg="placement">' + tx('Tiếp tục kiểm tra đầu vào', 'Continue placement') + '</button>' : ctx.mock ? '<button class="btn ghost" data-act="goArg" data-arg="mock|' + ctx.mock + '">' + tx('Về đề mock', 'Back to mock') + '</button>' : '') + '</div>';
    document.getElementById(id + 'r').addEventListener('click', () => { const b = $('#wsub'); if (b) b.disabled = false; const ta = $('#essay'); if (ta) { ta.focus(); ta.scrollIntoView({ behavior: 'smooth', block: 'center' }); } });
    if (ctx.place) { S.pd = S.pd || {}; S.pd.Wdone = 1; save(); } }, 0);
  return '<section class="card" id="' + id + '"><p class="pulse">…</p></section>';
};

// ---------- 3. Speaking: recorder + offline analysis ----------
const REC = { chunks: [], rec: null, urls: {}, t0: 0, dur: {} };
window.recUI = k => (navigator.mediaDevices && window.MediaRecorder ? '<section class="card recbox"><div class="row"><button class="btn alt sm" data-act="recToggle" data-arg="' + k + '" id="recb">' + ICON.mic + tx('Ghi âm câu trả lời', 'Record answer') + '</button>' + (REC.urls[k] ? '<audio controls src="' + REC.urls[k] + '"></audio>' : '') + '</div><p class="small muted">' + tx('Ghi âm để tự nghe lại phát âm, ngữ điệu và độ trôi chảy. Bản ghi chỉ nằm trên máy này.', 'Record to hear your pronunciation and fluency. Recordings stay on this device.') + '</p></section>' : '');
ACT.recToggle = async (k, btn) => {
  if (REC.rec && REC.rec.state === 'recording') { REC.rec.stop(); return; }
  try { const st = await navigator.mediaDevices.getUserMedia({ audio: true }); REC.chunks = []; REC.rec = new MediaRecorder(st); REC.t0 = Date.now();
    REC.rec.ondataavailable = e => REC.chunks.push(e.data);
    REC.rec.onstop = () => { st.getTracks().forEach(t => t.stop()); REC.dur[k] = (Date.now() - REC.t0) / 1000; if (REC.urls[k]) URL.revokeObjectURL(REC.urls[k]); REC.urls[k] = URL.createObjectURL(new Blob(REC.chunks, { type: REC.rec.mimeType })); const b = $('#recb'); if (b) { b.classList.remove('on'); b.closest('.recbox').querySelector('audio')?.remove(); b.insertAdjacentHTML('afterend', '<audio controls src="' + REC.urls[k] + '"></audio>'); b.innerHTML = ICON.mic + tx('Ghi lại', 'Record again'); } };
    REC.rec.start(); btn.classList.add('on'); btn.innerHTML = ICON.stop + tx('Dừng ghi', 'Stop');
  } catch (e) { toast(tx('Không mở được micro.', 'Microphone unavailable.')); }
};
const FILLERS = /\b(um+|uh+|er+|erm|ah|like|you know|i mean|kind of|sort of|actually|basically)\b/g;
window.offlineSpeak = (filled, out, ctx) => {
  const all = filled.map(x => x.a).join(' '); const low = all.toLowerCase(); const words = low.match(/[a-z][a-z'-]*/g) || []; const n = words.length;
  const content = words.filter(w => !STOP.has(w) && w.length > 2); const wn2 = content.slice(0, 120); const ttr = wn2.length ? new Set(wn2).size / wn2.length : 0;
  const fill = (low.match(FILLERS) || []).length; const link = LINKERS.filter(l => new RegExp('\\b' + l + '\\b').test(low));
  const adv = advWords(new Set(content));
  const idioms = (window.IDIOMS || []).flatMap(T => T.i.map(i => i[0].toLowerCase())).filter(i => low.includes(i));
  const complex = (low.match(/\b(which|who|because|although|if|when|while|whereas|since|that)\b/g) || []).length;
  const per = filled.map(x => ({ part: x.part, q: x.q, n: wc(x.a) }));
  const short = per.filter(p => (p.part === 1 && p.n < 20) || (p.part === 3 && p.n < 40) || (p.part === 2 && p.n < 150));
  const durs = Object.values(REC.dur); const tot = durs.reduce((a, b) => a + b, 0); const wpm = tot > 20 ? Math.round(n / (tot / 60)) : null;
  const G = [], B = [];
  short.length ? B.push(tx(short.length + ' câu trả lời còn ngắn – Part 1 nên 2–3 câu, Part 2 nói đủ 2 phút (~200 từ), Part 3 nêu lý do + ví dụ: ', short.length + ' short answers: ') + short.slice(0, 3).map(p => quote(p.q, 8)).join(', ')) : G.push(tx('Câu trả lời đủ dài, có phát triển ý.', 'Answers are well developed.'));
  link.length >= 3 ? G.push(tx('Có từ nối/diễn ngôn: ', 'Discourse markers: ') + link.join(', ')) : B.push(tx('Ít từ nối – thử: Well, actually…; The main reason is…; On the other hand…', 'Use more discourse markers.'));
  fill > 3 ? B.push(tx('Nhiều từ đệm (' + fill + ': um, like, you know…) – thay bằng khoảng dừng ngắn hoặc "Let me think…".', fill + ' fillers.')) : G.push(tx('Ít từ đệm (' + fill + ').', 'Few fillers.'));
  adv.size >= 4 ? G.push(tx('Từ vựng nâng cao: ', 'Advanced words: ') + [...adv].slice(0, 10).join(', ')) : B.push(tx('Chủ yếu dùng từ cơ bản – thêm vài từ B2+ hợp chủ đề (mục Kho tính từ, Đổi từ).', 'Mostly basic vocabulary.'));
  idioms.length ? G.push('Idioms: ' + idioms.join(', ')) : B.push(tx('Chưa dùng idiom – 1–2 idiom tự nhiên sẽ làm câu trả lời sinh động hơn.', 'No idioms yet.'));
  complex >= filled.length ? G.push(tx('Có câu phức (because, which, although…).', 'Uses complex sentences.')) : B.push(tx('Câu còn đơn giản – nối ý bằng because, which, although, if…', 'Use more complex sentences.'));
  if (wpm) (wpm >= 110 && wpm <= 170 ? G : B).push(tx('Tốc độ nói ~' + wpm + ' từ/phút (tự nhiên: 110–170).', 'Speed ~' + wpm + ' wpm.'));
  out.innerHTML = '<section class="card"><h2>' + tx('Nhận xét phần nói', 'Speaking feedback') + '</h2><p class="small muted">' + tx('Phân tích từ phần lời đã chuyển thành chữ (hoặc bạn gõ), không dùng AI và không chấm band. Phát âm không phân tích được – hãy nghe lại bản ghi âm và so với giọng mẫu.', 'Analysed from your transcript – no AI, no band. Compare your recording with the model voice for pronunciation.') + '</p>' +
    (G.length ? '<h3 class="ok">' + tx('Điểm mạnh', 'Strengths') + '</h3><ul class="chklist">' + G.map(x => '<li class="ok">✓ ' + x + '</li>').join('') + '</ul>' : '') + (B.length ? '<h3 class="bad">' + tx('Cần cải thiện', 'To improve') + '</h3><ul class="chklist">' + B.map(x => '<li class="bad">✗ ' + x + '</li>').join('') + '</ul>' : '') +
    '<div class="row"><button class="btn ghost" data-act="say" data-arg="' + esc(filled.map(x => x.a).join(' ').slice(0, 1500)) + '">' + ICON.speak + tx('Nghe giọng mẫu đọc câu trả lời của bạn', 'Hear your answer in a model voice') + '</button>' + (ctx && ctx.place ? '<button class="btn" data-act="nav" data-arg="placement">' + tx('Xem kết quả kiểm tra đầu vào', 'See placement results') + '</button>' : ctx && ctx.mock ? '<button class="btn" data-act="goArg" data-arg="mock|' + ctx.mock + '">' + tx('Về đề mock', 'Back to mock') + '</button>' : '') + '</div></section>';
  if (ctx && ctx.place) { S.pd = S.pd || {}; S.pd.Sdone = 1; save(); }
  reward(15, 0, 'Speaking'); markActive(); logHist('speaking', (filled[0] || {}).q ? filled[0].q.slice(0, 40) : 'Speaking', n + ' words');
};

// ---------- 4. "Tra cứu": search everything (replaces AI tutor) ----------
NAV.forEach(n => { if (n[0] === 'tutor') { n[1] = 'search'; n[2] = 'Tra cứu'; n[3] = 'Search'; } });
ICON.search = sv('<circle cx="11" cy="11" r="7"/><path d="M20 20l-4-4"/>');
function searchAll(q) {
  const n = nz(q); if (n.length < 2) return []; const out = []; const hit = s => nz(s).includes(n);
  allSubs().forEach(s => s.s.w.forEach(w => { if (hit(w[0]) || hit(w[2])) out.push([3 + (nz(w[0]) === n ? 5 : 0), w[0], w[2] + ' — ' + w[4], pick(s.tp.t) + ' › ' + pick(s.s.t), 'sub|' + s.key]); }));
  (window.ADJBANK || []).forEach(G => G.w.forEach(w => { if (hit(w[0]) || hit(w[1])) out.push([3 + (nz(w[0]) === n ? 5 : 0), w[0], w[1] + ' — ' + w[2], tx('Kho tính từ › ', 'Adjectives › ') + pick(G.g), 'adjbank|' + G.id]); }));
  (window.SWAP || []).forEach(g => { if (hit(g[0]) || hit(g[3]) || hit(g[2])) out.push([3, g[0] + ' → ' + g[3], g[2] + ' — ' + g[5], tx('Đổi từ', 'Word swaps'), 'swap|' + g[1]]); });
  (window.IDIOMS || []).forEach(T => T.i.forEach(i => { if (hit(i[0]) || hit(i[1])) out.push([3, i[0], i[1] + ' — ' + i[2], 'Idioms › ' + pick(T.th), 'idioms|' + T.id]); }));
  C.G.forEach(u => { if (hit(u.t[0]) || hit(u.t[1]) || hit(u.f)) out.push([4, pick(u.t), u.f, tx('Ngữ pháp ', 'Grammar ') + u.lvl, 'unit|' + u.id]); });
  C.P.forEach(p => { if (hit(p[0]) || hit(p[1])) out.push([2, p[0], p[1], tx('Cấu trúc tương đương', 'Paraphrasing'), 'learn|para']); });
  (window.WFAM || []).forEach(f => { if (f.slice(0, 4).some(hit)) out.push([2, f.slice(0, 4).join(' · '), f[4], tx('Họ từ', 'Word families'), 'swap|fam']); });
  (window.LIT || []).forEach(it => { if (hit(it.title)) out.push([2, it.title, it.by, tx('Văn & nhạc', 'Stories & songs'), 'litItem|' + it.id]); it.vocab.forEach(v => { if (hit(v[0])) out.push([2, v[0], v[2], it.title, 'litItem|' + it.id]); }); });
  LV.forEach(l => levelList(l).forEach(x => { if (nz(x.w) === n || (n.length >= 4 && nz(x.w).startsWith(n))) { const e = DICT[l][x.w]; out.push([nz(x.w) === n ? 6 : 1, x.w + ' (' + x.p + ')', e ? e[0] : '', tx('Từ điển ', 'Word list ') + l, 'dict|' + l + '|0|' + x.w]); } }));
  myItems().forEach(x => { if (hit(x.a) || hit(x.vi)) out.push([4, x.a, x.vi, tx('Kho của tôi', 'My library'), 'mine|' + x.kind]); });
  return out.sort((a, b) => b[0] - a[0]).slice(0, 60);
}
VIEWS.tutor = (q = '') => {
  const r = searchAll(q);
  page(head(tx('Tra cứu', 'Search'), tx('Tìm một từ, idiom, cấu trúc ngữ pháp hay chủ đề trong toàn bộ app – gõ tiếng Anh hoặc tiếng Việt.', 'Search words, idioms, grammar and topics across the whole app – English or Vietnamese.')) +
    '<section class="card"><form id="sf" class="gapf"><input id="sq" value="' + esc(q) + '" placeholder="' + tx('VD: increase, câu bị động, hạnh phúc…', 'e.g. increase, passive, happy…') + '" autocapitalize="off" autofocus><button class="btn">' + tx('Tìm', 'Search') + '</button></form></section>' +
    (q ? '<section class="card"><p class="muted small">' + r.length + tx(' kết quả', ' results') + '</p>' + r.map(x => '<div class="idiom"><div class="row between"><button class="link" data-act="goArg" data-arg="' + esc(x[4]) + '"><b>' + esc(x[1]) + '</b></button><span class="small muted">' + esc(x[3]) + '</span></div><span class="small">' + esc(x[2]) + '</span></div>').join('') + (!r.length ? '<p>' + tx('Không tìm thấy. Bạn có thể tự thêm vào ', 'Nothing found. Add it in ') + '<button class="link" data-act="goArg" data-arg="mine|word">' + tx('Kho của tôi', 'My library') + '</button>.</p>' : '') + '</section>' : '') +
    '<section class="card"><h2>' + tx('Mẹo học không cần AI', 'Study tips without AI') + '</h2><ul><li>' + tx('Không hiểu câu sai? Đọc phần giải thích sau mỗi câu, rồi tra cấu trúc ở đây.', 'Read the explanation after each question, then look the structure up here.') + '</li><li>' + tx('Bài Writing: dùng "Máy phân tích bài viết" sau khi nộp, sửa theo gợi ý rồi viết lại.', 'Use the writing analyser and rewrite.') + '</li><li>' + tx('Speaking: ghi âm, nghe lại, so với giọng mẫu.', 'Record yourself and compare.') + '</li></ul></section>');
  $('#sf').addEventListener('submit', e => { e.preventDefault(); go('tutor', $('#sq').value.trim()); });
};

// ---------- 5. Random mixed test (replaces AI-generated tests) ----------
const _tests = VIEWS.tests;
VIEWS.tests = (tab = 'skills', lf) => {
  _tests(tab, lf); const tb = $$('.tabs .tab').find(b => b.dataset.arg === 'tests|ai'); if (tb) tb.textContent = tx('Đề ngẫu nhiên', 'Random test');
  if (tab !== 'ai') return;
  const main = $('#main'); [...main.children].slice(2).forEach(c => c.remove());
  main.insertAdjacentHTML('beforeend', '<section class="card"><h2>' + tx('Tạo đề tổng hợp ngẫu nhiên', 'Build a random mixed test') + '</h2><p class="muted">' + tx('Trộn ngẫu nhiên câu hỏi ngữ pháp, từ vựng theo chủ đề, idioms, đổi từ, tính từ và họ từ đúng cấp độ – mỗi lần một đề mới.', 'Random grammar, vocabulary, idioms, word swaps, adjectives and word families at your level – a new test every time.') + '</p><form id="rtf" class="stackf"><label>' + tx('Cấp độ', 'Level') + '<select name="l">' + LV.map(l => '<option' + (l === S.level ? ' selected' : '') + '>' + l + '</option>').join('') + '</select></label><label>' + tx('Số câu', 'Questions') + '<select name="n"><option>20</option><option selected>30</option><option>40</option><option>60</option></select></label><label>' + tx('Chế độ', 'Mode') + '<select name="m"><option value="practice">' + tx('Luyện tập (xem đáp án từng câu)', 'Practice') + '</option><option value="timed">' + tx('Thi thật (bấm giờ)', 'Timed') + '</option><option value="rush">Rush</option></select></label><button class="btn">' + tx('Bắt đầu', 'Start') + '</button></form></section>');
  $('#rtf').addEventListener('submit', e => { e.preventDefault(); const d = new FormData(e.target); randomTest(d.get('l'), +d.get('n'), d.get('m')); });
};
function randomTest(l, n, mode) {
  const li = LVN[l]; const near = x => { const v = LVN[cefrOk(x)]; return v != null && Math.abs(v - li) <= 1; };
  const pool = [];
  C.G.filter(u => near(u.lvl)).forEach(u => u.q.forEach((_, i) => pool.push(() => gramQ(u, i))));
  allSubs().filter(s => !s.ai && near(s.s.lvl)).forEach(s => { const ws = wordsOf(s); ws.forEach(w => pool.push(() => vocabQ(w, ws, pick2(['mean', 'rev', 'cloze', 'syn'])))); });
  if (li >= 2) { (window.SWAP || []).forEach((_, i) => pool.push(() => swapQ(i, pick2(['syn', 'rev'])))); (window.WFAM || []).forEach((_, i) => pool.push(() => famQ(i))); (window.IDIOMS || []).forEach(T => T.i.forEach((_, i) => pool.push(() => idiomQ(T, i, Math.random() < .5)))); }
  if (li >= 2) (window.ADJBANK || []).forEach(G => G.w.forEach((_, i) => pool.push(() => ajQ('aj:' + G.id + '|' + i, pick2(['mean', 'shade', 'cloze'])))));
  const qs = shuffle(pool).slice(0, n * 2).map(f => { try { return f(); } catch (e) { return null; } }).filter(q => q && q.o && q.o.length >= 2).slice(0, n);
  runQuiz({ title: tx('Đề ngẫu nhiên ', 'Random test ') + l, qs, mode, time: n * 40, kind: 'random', back: () => go('tests', 'ai') });
}

// ---------- 6. Settings: voices, sync, backup file, install ----------
const _settings = VIEWS.settings;
VIEWS.settings = () => {
  _settings(); const c = Sync.cfg() || {}; const vs = Voice.voices(); const pref = localStorage.getItem('cozy__voice') || (Voice.best() || {}).name;
  const dataCard = $$('#main section.card').find(s => /Dữ liệu|Data/.test(s.querySelector('h2')?.textContent || ''));
  const html = '<section class="card"><h2>' + tx('Giọng đọc', 'Voice') + '</h2><p class="small muted">' + tx('App dùng giọng đọc có sẵn của thiết bị. Trên điện thoại Android, cài "Speech Services by Google" và tải gói giọng tiếng Anh để giọng tự nhiên hơn; trên Windows nên dùng Edge hoặc Chrome (có giọng "Online/Natural").', 'Uses your device voices. On Android install Speech Services by Google; on Windows use Edge or Chrome for natural voices.') + '</p>' +
    (vs.length ? '<label>' + tx('Chọn giọng', 'Choose voice') + '<select id="vsel">' + vs.slice().sort((a, b) => Voice.rank(b) - Voice.rank(a)).map(v => '<option' + (v.name === pref ? ' selected' : '') + ' value="' + esc(v.name) + '">' + esc(v.name) + ' (' + v.lang + ')</option>').join('') + '</select></label>' : '<p class="bad small">' + tx('Thiết bị chưa có giọng tiếng Anh.', 'No English voice on this device.') + '</p>') +
    '<div class="row"><button class="btn ghost sm" data-act="say" data-arg="Welcome to Cozy IELTS. The quick brown fox jumps over the lazy dog.">' + ICON.speak + tx('Nghe thử', 'Test') + '</button></div><p class="small muted">' + tx('Nhận dạng giọng nói (nút micro ở Speaking): ', 'Speech recognition: ') + (Voice.canListen() ? tx('có trên trình duyệt này (cần mạng).', 'available (needs internet).') : tx('trình duyệt này chưa hỗ trợ – dùng Chrome/Edge, hoặc nút micro trên bàn phím điện thoại.', 'not supported here – use Chrome/Edge or your keyboard mic.')) + '</p></section>' +
    '<section class="card"><h2>' + tx('Sao lưu & đồng bộ', 'Backup & sync') + '</h2><p class="small muted">' + tx('Dữ liệu nằm trong trình duyệt của máy này' + (Store.persisted ? ' (đã xin trình duyệt giữ lâu dài).' : '.') + ' Hãy bật đồng bộ GitHub hoặc tải file sao lưu định kỳ để không mất tiến độ.', 'Data lives in this browser. Turn on GitHub sync or download backups regularly.') + '</p>' +
    '<div class="row"><button class="btn" data-act="bkDown">' + tx('Tải file sao lưu (tất cả người học)', 'Download backup (all learners)') + '</button><label class="btn ghost">' + tx('Khôi phục từ file', 'Restore from file') + '<input type="file" id="bkfile" accept=".json,application/json" hidden></label></div>' +
    '<h3>' + tx('Đồng bộ qua GitHub (tuỳ chọn)', 'Sync via GitHub (optional)') + '</h3><p class="small muted">' + tx('Dùng chung tiến độ giữa máy tính và điện thoại. Tạo một "fine-grained token" trên GitHub chỉ có quyền Gists (đọc & ghi), dán vào đây. App lưu dữ liệu vào một gist bí mật của bạn. Token chỉ nằm trên máy này – đừng dùng trên máy công cộng.', 'Share progress between devices via a private gist. Create a fine-grained GitHub token with Gists read/write only. The token stays on this device.') + '</p>' +
    '<form id="syf" class="stackf"><label>Token<input name="token" type="password" value="' + esc(c.token || '') + '" autocomplete="off" placeholder="github_pat_…"></label><label>' + tx('Gist ID (để trống ở máy đầu tiên; máy thứ hai dán ID của máy đầu)', 'Gist ID (blank on the first device; paste it on the others)') + '<input name="gist" value="' + esc(c.gist || '') + '" autocomplete="off"></label><div class="row"><button class="btn">' + tx('Lưu & đồng bộ ngay', 'Save & sync now') + '</button>' + (c.token ? '<button type="button" class="btn ghost" data-act="syncOff">' + tx('Tắt đồng bộ', 'Turn off') + '</button>' : '') + '</div><p class="small muted">' + tx('Lần đồng bộ gần nhất: ', 'Last sync: ') + '<span id="syncst">' + (c.last ? new Date(c.last).toLocaleString() : '–') + '</span></p></form></section>';
  if (dataCard) { dataCard.insertAdjacentHTML('afterend', html); dataCard.remove(); } else $('#main').insertAdjacentHTML('beforeend', html);
  const vsel = $('#vsel'); if (vsel) vsel.addEventListener('change', () => localStorage.setItem('cozy__voice', vsel.value));
  $('#bkfile').addEventListener('change', async e => { const f = e.target.files[0]; if (!f) return; try { const b = JSON.parse(await f.text()); if (b.app !== 'cozy-ielts' || !b.keys) throw 0; Object.entries(b.keys).forEach(([k, x]) => { if (x.v != null) localStorage.setItem('cozy_' + k, x.v); }); const m = metaGet(); Object.keys(b.keys).forEach(k => m[k] = Date.now()); metaSet(m); toast(tx('Đã khôi phục – đang tải lại…', 'Restored – reloading…')); setTimeout(() => location.reload(), 800); } catch (err) { toast(tx('File không hợp lệ.', 'Invalid file.')); } });
  $('#syf').addEventListener('submit', async e => { e.preventDefault(); const d = new FormData(e.target); const tok = String(d.get('token')).trim(); if (!tok) return; Sync.save({ token: tok, gist: String(d.get('gist')).trim() || null }); toast(tx('Đang đồng bộ…', 'Syncing…'));
    try { const n = await Sync.pull(); await Sync.push(); const c2 = Sync.cfg(); modal('<div class="center"><p>' + tx('Đồng bộ xong! ', 'Synced! ') + (n ? tx('Đã nhận ' + n + ' mục từ máy khác.', 'Received ' + n + ' items.') : '') + '</p><p class="small">Gist ID: <b>' + esc(c2.gist) + '</b></p><p class="small muted">' + tx('Dán ID này vào máy còn lại.', 'Paste this ID on your other device.') + '</p><button class="btn" data-act="reloadApp">OK</button></div>'); }
    catch (err) { toast(tx('Không đồng bộ được (mã ' + (err.code || '?') + '). Kiểm tra token có quyền Gists.', 'Sync failed (' + (err.code || '?') + ').')); } });
};
ACT.reloadApp = () => location.reload();
ACT.syncOff = () => { localStorage.removeItem('cozy__sync'); toast(tx('Đã tắt đồng bộ.', 'Sync off.')); rerender(); };
ACT.bkDown = () => { const b = Sync.bundle(); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(b)], { type: 'application/json' })); a.download = 'cozy-ielts-backup-' + today() + '.json'; document.body.appendChild(a); a.click(); a.remove(); localStorage.setItem('cozy__lastbk', today()); toast(tx('Đã tải file sao lưu.', 'Backup downloaded.')); };
// backup reminder on home every 7 days when sync is off
const _home2 = VIEWS.home;
VIEWS.home = () => { _home2(); const lb = localStorage.getItem('cozy__lastbk'); if (!Sync.on() && (!lb || daysBetween(lb, today()) >= 7) && S && S.hist.length > 5) { const hero = $('.hero'); hero && hero.insertAdjacentHTML('afterend', '<section class="card warnbox"><p>' + tx('Dữ liệu đang chỉ nằm trên máy này. ', 'Your data is only on this device. ') + '<button class="link" data-act="bkDown">' + tx('Tải file sao lưu', 'Download a backup') + '</button> · <button class="link" data-act="nav" data-arg="settings">' + tx('Bật đồng bộ GitHub', 'Turn on GitHub sync') + '</button></p></section>'); } };

// ---------- 7. Offline install (PWA) ----------
if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  navigator.serviceWorker.register('sw.js').then(reg => { reg.addEventListener('updatefound', () => { const nw = reg.installing; nw && nw.addEventListener('statechange', () => { if (nw.state === 'installed' && navigator.serviceWorker.controller) toast(tx('Có bản cập nhật mới – đóng và mở lại app để dùng.', 'Update ready – reopen the app.')); }); }); }).catch(() => {});
}
// placement: Writing/Speaking have feedback but no band in this edition
const _plc = VIEWS.placement;
VIEWS.placement = () => { _plc(); const pd = S.pd || {}; const st = $$('.steps .step'); [['W', 3], ['S', 4]].forEach(([k, i]) => { if (pd[k + 'done'] && st[i] && !st[i].classList.contains('done')) { st[i].classList.add('done'); const p = st[i].querySelector('p'); if (p) p.insertAdjacentHTML('beforeend', ' · ' + tx('đã có nhận xét (không tính band)', 'feedback given (no band)')); } }); };
